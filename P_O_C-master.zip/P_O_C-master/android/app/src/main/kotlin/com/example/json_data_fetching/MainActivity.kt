package com.example.json_data_fetching

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
